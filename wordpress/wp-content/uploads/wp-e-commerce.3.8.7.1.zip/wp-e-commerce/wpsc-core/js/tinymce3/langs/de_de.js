// German lang variables for WP2.5

tinyMCE.addI18n({de:{
NextGEN:{	
desc : 'NextGEN Gallery hinzufuegen'
}}});
