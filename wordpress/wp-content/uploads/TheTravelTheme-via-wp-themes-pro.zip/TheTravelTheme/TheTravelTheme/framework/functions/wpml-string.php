<?php
wpml_register_string( THEME_NAME , 'Top Area Html Code', stripslashes(theme_get_option('general','top_area_html')));
wpml_register_string( THEME_NAME , 'Portfolio More Button Text', theme_get_option('portfolio','more_button_text'));
wpml_register_string( THEME_NAME , 'Copyright Footer Text', stripslashes(theme_get_option('footer','copyright')));
wpml_register_string( THEME_NAME , 'Footer Right Area Html Code', stripslashes(theme_get_option('footer','footer_right_area_html')));
