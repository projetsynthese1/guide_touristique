/*------------------------------------------------------------------------
# TheTravelTheme - A free wordpress theme - January 2011
# ------------------------------------------------------------------------
# Copyright (C) 2011 Switched on Media. All Rights Reserved.
# @license - TheTravelTheme is available under the terms of the Creative Commons Attribution-NoDerivs 3.0 Unported (CC BY-ND 3.0)
# Human readable summary http://creativecommons.org/licenses/by-nd/3.0/
# Author: Switched on Media
# Websites:  http://www.switchedonmedia.com.au
-------------------------------------------------------------------------*/
TheTravelTheme Wordpress Theme
============================
Thanks for downloading a copy of TheTravelTheme, a free Wordpress theme. 
This readme should get you started with everything you need to know
Requirements
============
This theme is designed to work with Wordpress 3.0 and above so if you haven't
already upgraded you may want to look into that first. 
Installation 
============
WORDPRESS DASHBOARD
1. Login to Wordpress - http://www.yourdomain.com/wp-admin
2. Navigate to Appearance > Themes
3. Select Install Themes > Upload
4. Upload TheTravelTheme.zip
5. Activate
FTP
1. Login to Wordpress using FTP, and create a folder called thetraveltheme at /wp-content/themes/thetraveltheme/ 
2. Unzip everything to that folder
3. Log in to Wordpress, select Apparances, Themes, and activate TheTravelTheme.
4. That's it, you're all set to go!
For detailed instructions about setting up the homepage, navigation, footer, sidebar and/or menu, please visit http://thetraveltheme.com/quickstart-guide-installation/
Licensing & Theme Usage
=======================
This theme is 100% free to use! All we ask is that you keep the link going back to Quickbeds.com in the footer.
This helps let others know about the theme, so that they too can use it.
