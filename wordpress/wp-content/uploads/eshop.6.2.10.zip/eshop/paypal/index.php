<?php
### PAYPAL CONFIG ###################################################
### use this to set any paypal specifics
### DO NOT EDIT BELOW THIS POINT ####################################
$itemoption='on0_';
?>