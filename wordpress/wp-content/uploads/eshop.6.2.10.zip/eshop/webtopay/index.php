<?php
//special settings - copy from webtopay index if none.
$itemoption='on0_';
?>